# Dentro del módulo creamos las funciones de la calculadora
def suma(num1, num2):
    return num1 + num2


def resta(num1, num2):
    return num1 - num2


def multiplicar(num1, num2):
    return num1 * num2


def division(num1, num2):
    return num1 / num2
