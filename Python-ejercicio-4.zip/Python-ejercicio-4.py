i = 100
while i > 0:
    print(i)
    i -= 1
